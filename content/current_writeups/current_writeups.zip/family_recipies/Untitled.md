

# 

# 

# 

# 

# 

















































# 





# *Family Recipe Module- 









































## Character Sheet- Grandmother Linda Glynhall











# 

# 

















# 

# 









# *Family Recipe Module- 













































# *Family Recipe Module- You Found Charlie*

**Written By:** Brittney Perry

**Reviewed By:**



**Brief:**

​	Congratulations! You have found the grandson Charlie! He has turned up on his own in the tavern being a belligerent drunk.



**Requirements:**

​	The INcompletetion of the module OPERATION FIND CHARLIE  



**Synopsis:**

​	Granny Linda was very helpful in describing her grandson and now the PCs are able to track Charlie to his hideout. Unfortunately for Charlie, he is sober, outnumbered  and out-weaponed. He will try to bluff his way into getting them to leave and if that doesn't work, he will run rather than fight. The treasure is left unguarded and free for the taking if the PCs wish.



**Outcomes:**

- The PCs track Charlie back to the cache of the Felhand. Ultimately, Charlie will run off leaving the treasure unguarded.
  - 

**Rumors:** 

​	None



**Hook:**

​	None



**Number of Cast Members:**

​	1



**Roles:**

​	Charles “Charlie” Glynhall



**Props:**

​	None



**Tags and Treasure:** 

- Gold
- Components
- Silver
- Jewelry
- Potions
- Gasses
- Granny's Recipe Book



**Scene 1:**

Clearing in the woods



**Flee Point:** 

​	Out of sight



**Non-Standard Effects:** 

​	None



**Rules Clarification:**

​	None



**Craftsman Information:**

​	None



**Transformations:**

​	None



**Running Notes:**

- The treasure chest has an emblem burned into the top [or painted] of the Felhands
- The completion of this module [or the taking of the treasure in any way] spawns the **Felhand Module Pack**

























































## Character Sheet- Charles “Charlie” Glynnhall



*Charlie is a simple man, who loves his Granny. Unfortunately, Charlie has fallen in with the wrong crowd. The Felhands came a'calling one day, and ol' Charlie answered. Now, he's a Felhand Meatshield, who get's 2% of all treasure stolen or goods fenced as payment for his services.*



*Charlie is a self centered and selfish dwarf who thinks of nothing but himself. He is crass and sarcastic, entitled, lazy, and a coward. Charlie only thinks of Charlie and how things effect him.*





***Traits:***

- *Absentminded- Charlie would lose his head if it wasn't attached*
- *Abrasive-No one really likes Charlie. He is gruff, angry, short tempered, and just all around an disagreeable man to be around. The complete opposite of Granny.*
- *Aggressive-You looking at me funny? You wanna fight? Let's go outside!*
- *Callous- He can't be bothered to care about pretty much anything or anyone, except his Granny, and that doesn't include not robbing her.*
- *Careless- He gave no effort in hiding his trail out to the treasure box, or make himself unnoticeable in the tavern he chose to get drunk in.*
- *Charmless- Charlie couldn't charm a wort on a toad, much less charm a person.*
- *Conceited- He thinks he is the perfect specimen, despite having never won a fight.*
- *Coweredly- If a real fight breaks out, Charlie will always run. Being pressed even a little bit has him spouting family secrets.*
- *Criminal- Charlie sees nothing wrong in taking what isn't his. After all, it was owed to him*
- *Dependent- If it hadn't been for his grandmother, Charlie would have lived and died in a gutter. He lacks the willpower to take care of himself.*
- *Desperate- Charlie has a severe gambling and drinking problem he has to finance. He has no job.*
- *Dishonest- Charlie will shake your hand with one hand and with the other, stab you in the back. You couldn't trust it if this man told you the sky was blue and the grass was green.*  
- *Dramatic- Oh woe is me! Everything is awful and it's the worse it could be!*
- *Entitled- The world owes Charlie everything.*   
- *Greedy- Charlie wants all the money, he just doesn't want to work for it.*
- *Gullible- The Felhand was able to convince Charlie to be their stooge, and to steal Granny's book.*
- *Lazy- The only thing Charlie has been on time for is his dinner. And don't give him anything to do with a deadline*
- *Narcissistic- Charlie is incredibly self centered, and only thinks of others when it benefits him*
- *Opportunistic- When a chance to make a quick buck comes along, Charlie is right there to swindle people out of their gold. No job is off limits, except for killing.*
- *Proud- Charlie has a strong dwarven pride, even though he shouldn't be proud of the things he's done.*
- *Resentful- Charlie, even though he loves his Granny, he resents her not letting him go out and adventure. He resents everyone else's good fortune. And he resents the fact that he isn't in charge of the Felhand.*
- *Sarcastic- Charlie has a sarcastic tone of voice, and uses sarcasm frequently*
- *Selfish- Charlie is incredibly selfish, even for a dwarf.*  
- *Stressed- After becoming a Fellhand, Charlie started seeing people following him. After the stress of the occupation and the paranoia of being followed, Charlie started biting his nails as a stress response.*
- *Stubborn- A dwarf with dwarven stubbornness*
- *Thievish- Charlie will, and has, robbed is own Grandmother blind. You think your purse is safe?*
- *Tough- Say what you want about Charlie, but he can sure take a beating.*
- *Unprincipled- Charlie doesn't have a code he lives by, he usually just does what ever feels good in the moment.*



**Reset:** Yes, resurrect, draw from bag, one stone in bag



**Movement:** Normal human



**Speech:** Normal, but sub par, intelligence



**Body:** 200



**Defensives:** None



**Weapons:**



**Damage:**



**Magic:**



**Abilities:**



**Killing Blow:**



**Motivations**



**Tactics:**



**Costuming:** Typical dwarven clothing, messy beard and braids. Unkempt clothing. Cloth tied around left hand to hide Felhand tattoo. A hand drawn map with an X marking the Felhand treasure should be on his person until taken by the PCs.





















# *Family Recipes Module- Cash in The Cache*

**Written By:** Brittney Perry

**Reviewed By:**



**Brief:** 

​	Having met no resistance at the cache of the Felhand, the PCs return to Granny Glynhall to return her book and take word of her grandson to her.**
**

**Requirements:**

​	Completion of **OPERATION- FIND CHARLIE** or **YOU FOUND CHARLIE**



**Synopsis:**

​	The finding of the book was easier than expected, plus there was a good haul of treasure for the taking. Granny is eager to get her book back, and if it shows up in town, Granny will send a messenger requesting that the group bring the book to her. 

​	Once back at Granny's house, she will offer the group cookies with a potion kick and thank them profusely. She wants to hear all about their adventure and how they found her book. She will venomously deny that her grandson had anything to do with her books disappearance and will change the subject if it is brought up. 

​	Eventually, Granny will get annoyed that everyone is insisting her grandson stole her book and kick out the PCs or the PCs can leave freely, as long as they leave the book. Granny will pay the 20 Silver reward before they leave.



**Outcomes:**

- The PCs return the book and retrieve their reward



**Rumors:**

​	None



**Hook:**

​	None



**Number of Cast Members:**

​	1



**Roles:**

​	Grandmother Linda Glynhall



**Props:**

- Edible cookies
- Granny's Recipe Book



**Tags and Treasure:** 

- Cookies
- 20 Silver





**Scene 1:** 

​	Granny's House 



**Flee Point:**

​	None



**Non-Standard Effects:**

None



**Rules Clairification:**

None



**Craftsman Information:**

None



**Transformations:**

None



**Running Notes:**





# 









































































# *Family Recipes Module- Returning Charlie*

**Written By:** Brittney Perry

**Reviewed By:**



**Brief:** 

​	Charlie, as fast as he is, has gotten himself caught by the PCs. Charlie is then returned to his Grandmother's house. Granny chastises him, and gives the map he is carrying to the PCs.**
**

**Requirements:**

PCs are able to catch and return Charlie to his Grandmother.

 

**Synopsis:**

​	Charlie, at some point, gets himself caught and returned to his Grandmother. He refuses to speak in her presence, and really, Granny doesn't let him even try. She interrupts him whenever he tries to speak, chastising him. She insists he turn out his pockets and give his money to the PCs because “he can't be trusted with it”. Unfortunately, Charlie doesn't have any money, but he turns out a map that is quickly grabbed by Granny and handed over to the PC's. If the map is already possessed by the PCs, she finds nothing and will ask that they leave so that she can properly scold her Grandson.



**Outcomes:**

- The PCs return Charlie to Granny



**Rumors:**

​	None



**Hook:**

​	None



**Number of Cast Members:**

​	2



**Roles:**

- Grandmother Linda Glynhall
- Charles “Charlie” Glynhall



**Props:**

​	Treasure Map



**Tags and Treasure:** 

​	None



**Scene 1:** 

​	Granny's House



**Flee Point:**

​	None





**Non-Standard Effects:**

​	None



**Rules Clairification:**

​	None



**Craftsman Information:**

​	None



**Transformations:**

​	None



***Running Notes:***









































































# *Family Recipes Module- EMERGENCY! Help Wanted!*

**Written By:** Brittney Perry

**Reviewed By:**



**Brief:

**	Charlie gave up the Felhand's treasure and went back to his grandmother's house. Charlie and Granny are abducted by the Felhand, who want their treasure back. Charlie is beaten and allowed to go back into town, to find the ones who stole their treasure and get it back. A note and a finger is sent into town by a messenger. Anything short of prompt payment by Charlie will prove to be fatal for Granny. 



**Requirements:**





**Synopsis:**



**Outcomes**



**Rumors**



**Hook:**



**Number of Cast Members:**



**Roles:**



**Props:**



**Tags and Treasure:** 



**Scene 1:** 

**Scene 2:** 

**Scene 3: ect...** 



**Flee Point:**



**Non-Standard Effects:**



**Rules Clairification:**



**Craftsman Information:**



**Transformations:**



***Running Notes:***



















# *Family Recipes Module- The Exchange*

**Written By:**

**Reviewed By:**



**Brief:

**

**Requirements:**



**Synopsis:**



**Outcomes**



**Rumors**



**Hook:**



**Number of Cast Members:**



**Roles:**



**Props:**



**Tags and Treasure:** 



**Scene 1:** 

**Scene 2:** 

**Scene 3: ect...** 



**Flee Point:**



**Non-Standard Effects:**



**Rules Clairification:**



**Craftsman Information:**



**Transformations:**



***Running Notes:***