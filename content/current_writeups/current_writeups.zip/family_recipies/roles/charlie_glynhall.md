---
title: "Charlie Glynhall"
date: 2022-11-10T10:33:21-05:00
draft: false
weight: 10
description: Grandson of Granny Glynhall, has always had his problems. He's not to bright, and is always getting into trouble. After losing his parents at a young age, he was sent to be raised by his grandmother. Granny did her best, but Charlie wanted more than she was able to give. He craved adventure, but his grandmother, knowing where that type of life leads, forbade him from leaving the city. When the Orcs took over Stonewood, Charlie saw the perfect opportunity He tried to rebel and take down the orcs, but was quickly beaten to within an inch of his life. Not by the Orcs; they wouldn't have left him alive. No, he was beaten by his neighbors, because anyone who defied the Orcs would bring their wrath down upon everyone. Chastised and wounded, Charlie spent the remainder of the occupation holed up in Granny's house. When the city was liberated, Charlie took to his new found freedom by drinking and gambling in excess. When his money ran out, he started borrowing. Soon, no one would lend him money or drink and Charlie found himself in trouble again, this time seemingly at the end of his rope.
---

