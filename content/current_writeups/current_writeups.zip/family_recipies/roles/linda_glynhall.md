---
title: "Grandmother Linda Glynhall"
date: 2022-11-10T10:33:21-05:00
draft: false
weight: 10
description: a long retired adventurer, is quite glad the occupatoin of Stonewood is over. Having spent the summer under brutal occupation and the long winter just trying to survive, this spring brings with it a renewed vigor that can only come from a newfound freedom. “Granny”, hearing that the adventurer's would be returning to Stonewood, has decided to bake up a delicious batch of cookies as a thank you. Only one problem, her recipe book has gone missing!
introduction: > 
  Oh dear! Look at you! What a lovely sweater! Are you hungry? Thirsty? Need a healing? Granny's here to help!” At the tender young age of 90, Granny is a lovely, squat, old figure in the local community. She has never met a stranger, and welcome all who come to her door!
  When the occupation happened, Granny kept her head down and did as she was told. She allowed her neighbors to “teach Charlie a lesson”, even though it hurt her to know what he had to go through. He was bound to be caught by the Bloody Fist and killed, and possibly Granny Linda along with him.
Motivation: She wants her book back. And she wants someone to find her grandson Charlie. She is willing to share information to achieve those goals.
Costume: Silver or gray wig, tied up into a bun. A very well kept beard with braids and ribbons. Apron and floral dress, with a dusting of flour. She smells like cookies.
Magic: 6 Earth Block
---

## 



***Traits:***

- *Adventurous- Granny is an earth scholar with a 6 block of spells and a duel wield skill. Nowadays, Granny weilds a frying pan and healing spells.*
- *Anxious- Granny is worried about her grandson and her beloved recipe book*
- *Blunt- Granny is too old to mince words. While she is never outright rude, she has been known to be blunt to the point of almost rude. [Think southern grandma that doesn't like you]*
- *Charismatic- No matter what, Granny is just hard not to love. She is warm and welcoming, and can make almost anyone love her.*
- *Educated- Granny didn't get to be where she is without being well learned. She can read and write of course, but also is knowledgeable about the city, the Orcs, and the previous war.*  
- *Empathetic- Granny empathizes with others easily. She is old, and has seen a lot, which makes her very empathetic.*  
- *Familial- She's a dwarf of the ***SOMETHING** clan*
- *Forgetful- She's 90, and forgets new information easily. Old information (over a year old) is better remembered, but still hard. Granny can recall her youth fairly easily.*
- *Good Natured- Granny has an inherent friendly nature.*
- *Gullible- She may be eduacted, but Granny is easily convinced if she thinks you are telling the truth or trusts you. She is also believes anything her grandson tells her.*
- *Patient- With old age comes a depth of patience that only old age can bring.*
- *Protective- Granny loves everyone and will do her best to protect those she takes a shine to.*
- *Proud- A pride only dwarves can have.*
- *Stubborn- And the stubbornness of a dwarf too.*
- *Strong- Granny is a secrete badass, having spent her entire youth exploring and fighting in some of Elysia's most dangerous lands.. Even after taking in her grandson, Granny still used her skills to help around her area of the city.*  
- *Soothing- Granny should give off a since of safety. People should be put at ease by her presence. She should want to be helpful, opening healing pools and healing if she sees a need.*  

**Movement: S**huffled, stooped gate. Slow. Movement should look like it's hard to do [like an old person]. 

**Speech:** Soft spoken and intelligent, with a hint of anxiety

**Body:** **high*

