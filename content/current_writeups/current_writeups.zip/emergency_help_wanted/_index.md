---
title: "Emergency Help Wanted"
date: 2022-11-10T10:33:21-05:00
draft: false
weight: 10
Layout: module
day: friday
author: Brittney Perry
description: Granny Linda Glynhall's family recipe book has gone missing! Also, she hasn't seen her grandson Charlie in three days. In desperation, she has put two ads in the local paper asking for help finding them both. She has offered a reward for the return of each.

---
